# Webdriver torso generator (CREDITS TO Paul aphanasyev)

A Pen created on CodePen.

Original URL: [https://codepen.io/segxoupl-the-solid/pen/LEpowWm](https://codepen.io/segxoupl-the-solid/pen/LEpowWm).

